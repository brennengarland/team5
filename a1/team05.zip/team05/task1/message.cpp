#include <iostream>
#include "message.h"
using namespace std;

//example class function
void message::printMessage(){
    cout << "Makefile Example\n";
}
