#ifndef MESSAGE_H
#define MESSAGE_H

//example class header file for message class
class message{

public:
    void printMessage();
};

#endif // MESSAGE_H