#include "message.h"
#include <cstdlib>

using namespace std;
//main example from video
int main()
{
    //make a message
    message m;
    //call m's printMessage function and show the example
    m.printMessage();

    return 0;
}