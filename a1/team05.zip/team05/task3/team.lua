--      (15) Write a Lua program (filename: team.lua) that prints your team number to the
--      terminal 10 times.

--loops through 10 times and prints the team number
for i=1,10 do 
    print("Iteration: " .. i .. ", Team Number: 5") 
end