

gameobjs = {}
gameobjs["player1"] = { kind = "chopper", xpos = 50,  ypos = 50,  xvel = 0.5, yvel = 0.5 }
gameobjs["player2"] = { kind = "tank",    xpos = 0,   ypos = 0,   xvel = 0.5, yvel = 0.5 }
gameobjs["player3"] = { kind = "pacman",  xpos = 100, ypos = 100, xvel = 0.5, yvel = 0.5 }
gameobjs["player4"] = { kind = "tank",    xpos = 150, ypos = 150, xvel = 0.5, yvel = 0.5 }
gameobjs["player5"] = { kind = "chopper", xpos = 200, ypos = 200, xvel = 0.5, yvel = 0.5 }
