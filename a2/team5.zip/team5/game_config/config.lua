--
-- Lua configuration script
-- read this script on program startup to specify initial
-- window location and dimensions
-- 
xpos = 100
ypos = 100
width = 100
height = 100
fullscreen = false
